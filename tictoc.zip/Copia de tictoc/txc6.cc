#include <stdio.h>
#include <string.h>
#include <omnetpp.h>

using namespace omnetpp;

class Txc6 : public cSimpleModule
{
  private:
    cMessage *event = nullptr;      // Puntero al objeto de evento utilizado para el temporizador
    cMessage *tictocMsg = nullptr; // Puntero al mensaje para enviar

  public:
    virtual ~Txc6();

  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

Define_Module(Txc6);

// Destructor de la clase Txc6
Txc6::~Txc6()
{
    // Libera la memoria de los objetos creados dinámicamente
    cancelAndDelete(event);
    delete tictocMsg;
}

// Inicialización del módulo
void Txc6::initialize()
{
    // Creamos el objeto de evento que se utilizará para el temporizador (self-message)
    event = new cMessage("event");

    // No hay mensaje tictocMsg aún
    tictocMsg = nullptr;

    // Si el módulo es "tic", programamos el primer envío después de 5 segundos simulados
    if (strcmp("tic", getName()) == 0) {
        EV << "Programando primer envío para t=5.0s\n";
        tictocMsg = new cMessage("tictocMsg");
        scheduleAt(5.0, event);
    }
}

// Manejo de los mensajes recibidos por el módulo
void Txc6::handleMessage(cMessage *msg)
{
    // Si el mensaje es el evento de temporizador
    if (msg == event) {
        // El período de espera ha terminado, enviamos de vuelta el mensaje
        EV << "Periodo de espera terminado, enviando de vuelta el mensaje\n";
        send(tictocMsg, "out");
        tictocMsg = nullptr; // Limpiamos el puntero
    }
    else {
        // El mensaje es el mensaje tic-toc que llega desde el otro módulo
        EV << "Mensaje recibido, comenzando a esperar 1 segundo...\n";
        tictocMsg = msg; // Guardamos el mensaje recibido
        scheduleAt(simTime()+1.0, event); // Programamos el temporizador para dentro de 1 segundo
    }
}



