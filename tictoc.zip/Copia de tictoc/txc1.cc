/*
 * txc1.cc
 *
 *  Created on: 20 feb. 2024
 *      Author: luismi
 */
#include <string.h>     // Incluye la librería para manejo de cadenas de caracteres.
#include <omnetpp.h>    // Incluye la librería principal de OMNeT++.

using namespace omnetpp; // Utiliza el espacio de nombres de OMNeT++.

/**
 * Define la clase Txc1 como una subclase de cSimpleModule.
 */
class Txc1 : public cSimpleModule
{
  protected:
    // Las siguientes funciones virtuales redefinidas contienen la lógica del módulo.
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

// Registra la clase de módulo con OMNeT++
Define_Module(Txc1);

void Txc1::initialize()
{
    // initialize() se llama al comienzo de la simulación.
    // Para iniciar el proceso tic-toc-tic-toc, uno de los módulos debe
    // enviar el primer mensaje. Vamos a suponer que es el módulo 'tic'.

    // ¿Soy Tic o Toc?
    if (strcmp("tic", getName()) == 0) {
        // Crea y envía el primer mensaje por la puerta "out". "tictocMsg" es una
        // cadena arbitraria que será el nombre del objeto mensaje.
        cMessage *msg = new cMessage("tictocMsg");
        send(msg, "out");
    }
}

void Txc1::handleMessage(cMessage *msg)
{
    // El método handleMessage() se llama siempre que llega un mensaje
    // al módulo. Aquí, simplemente lo enviamos al otro módulo, a través de
    // la puerta 'out'. Como tanto 'tic' como 'toc' hacen lo mismo, el mensaje
    // rebotará entre los dos.
    send(msg, "out"); // Envía el mensaje hacia fuera.
}



